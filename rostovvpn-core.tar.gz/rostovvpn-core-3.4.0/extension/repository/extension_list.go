package repository

import (
	_ "github.com/Darkmen203/rostovvpn-app-demo-extension/rostovvpn_extension"
	_ "github.com/Darkmen203/rostovvpn-ip-scanner-extension/rostovvpn_extension"
)
