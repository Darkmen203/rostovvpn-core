//go:build !bydll

package main

func main() {}
