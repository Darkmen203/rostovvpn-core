package repository

import (
	_ "github.com/Darkmen203/rostovvpn-app-demo-extension/hiddify_extension"
	_ "github.com/Darkmen203/rostovvpn-ip-scanner-extension/hiddify_extension"
)
